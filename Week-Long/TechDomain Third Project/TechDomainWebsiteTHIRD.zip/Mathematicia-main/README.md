# :beginner: ***Mathematicia*** :beginner:

## Server Monks Community ##

Team TA_Invictus Belongs to Server Monks Community and is the very small team within it. Copyrights of Mathematicia also belongs to Server Monks Community.

## Server Monk Contributors ##

Many contributors within ***Server Monks Community*** contributed in the designing and development of ***Mathematicia*** . They Continuously helped team ***TA_Invictus*** as it is the part ***SMC*** itself. ***SERVER MONKS COMMUNITY*** believes in learn and grow together and with this inspiration ***TA_Invictus*** within ***Server Monks Community*** came up with this project.   


## TA – INVICTUS ##
Team members: <br/> 

 * Rohit Bhat
 * Harsh Niture
 * Chinmay Chougule
 * Meenal Garg

## Theme: Education ##

### Project Description:- ###
“Mathematics is not about numbers, equations, computations and algorithms; it is about understanding”

This understanding is what our team INVICTUS provides through MATHEMATICIA.

Youth are the nation's future, and the 10th and 12th grades are among the most crucial years of a student's life since these grades present a major challenge i.e. Boards.
To help students along their journey to a successful preparation with the right intake of knowledge is what Mathematicia is developed to achieve. 

We provide students with all required study resources on a single platform, taking into account the time restrictions that these boards impose.
Also due to this ongoing COVID-19 pandemic, students are not able to go to libraries or access offline study materials, therefore this is a little initiative from our team to help students virtually. 

# :maple_leaf: [Click here](https://rohitbhat1603.github.io/Mathematicia/) to view our project

## Education Purpose ##
Our Website ***Mathematicia*** is helpful for 10 th and 12 th grade students as it provides all the study materials at one place.
We added services like Topicwise videos, notes, quizes, previous year questions etc. so that they can find it easily and study properly without any searching stress.
Mathematicia will always be improving its features to make user more reliable.
